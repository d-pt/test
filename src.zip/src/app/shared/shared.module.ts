import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTabsModule } from '@angular/material/tabs';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatGridListModule,
  MatCardModule} from '@angular/material'; //another way to import
import {NoopAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  imports: [
    CommonModule,
    MatTabsModule,//not sure if this is required
    
    NoopAnimationsModule
  ],
  exports:[
    MatTabsModule,
    MatSidenavModule,
    MatGridListModule,
    MatCardModule,
    MatGridListModule,
    MatCardModule
  ],
  declarations: []
})
export class SharedModule { }
